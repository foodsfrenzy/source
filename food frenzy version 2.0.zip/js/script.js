$(document).ready(function(){
	$("#registeruser").on('submit',function(e){
		e.preventDefault();
		console.log('submitted');
		var name = $("#uname").val();
		var email = $("#uemail").val();
		var pass = $("#upass").val();
		var contact = $("#ucontact").val();
		var secure = "JgWnXBbal3mek-EMSQEzrdrUhFvsLLBi";
		$.ajax({
			  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Email%22:%20%22'+email+'%22}&fo=true&apiKey='+secure+'',
			  dataType: "json",
			  type: 'GET',
			  cache: false,
			  success: function (data) {
				//the variable 'data' will have the JSON object
				// In your example, the following will work:
				
				
				if(data==null){
					
					console.log('Email Doesnot Exist');
					$.ajax({
						  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Contact%22:%22'+contact+'%22}&fo=true&apiKey='+secure+'',
						  dataType: "json",
						  type: 'GET',
						  cache: false,
							success: function (contactdata) {
						
						if(contactdata == null){
							console.log('Contact Doesnot Exist');
							
							$.toast({
																heading: 'Failed',
																text: 'Email Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'success',
																bgColor: '#5EEA50',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#9EC600',
																hideAfter: 6000,																
																stack: false,
																
												})
							$.ajax({ 
									url: "https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?apiKey="+ secure +"",
									data: JSON.stringify( { 
									"Name" : name,
									"Email" : email,
									"Password": pass,
									"Contact": contact
									
									} ),
									type: "POST",
									contentType: "application/json",
									success: function(data){
										
										$.toast({
																heading: 'success',
																text: 'Registered Successfully',
																position: 'top-center',
																allowToastClose: true,
																icon: 'success',
																bgColor: '#5EEA50',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#9EC600',
																hideAfter: 6000,																
																stack: false,
																afterShown: function () {
																	window.location.replace("index.html");
																}
												})
										
										
										
									},
									error: function(xhr, status, err){
										
										
									}
							});
						
							
							
						}
						else {
						console.log('Contact Exist');
						}
						
					}
					
					
					
					});
					
					
					
				}
				else {
					
					
						console.log('User Exists');
						
						
					
					
					
				}
			   
			  }
			});
		
		
		
	});
	
	
});
$(document).ready(function(){
	$("#loginuser").on('submit',function(e){
		e.preventDefault();
		console.log("clicked");
		var secure = "JgWnXBbal3mek-EMSQEzrdrUhFvsLLBi";
		var loginname = $("#loginname").val();
		var loginpass = $("#loginpass").val();
		var check=loginname.search("@");
		var s=sessionStorage.getItem("user");
		if(s==null){
					if(check==(-1)){
			$.ajax({
											  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Contact%22:%20%22'+loginname+'%22}&fo=true&apiKey='+secure+'',
											  dataType: "json",
											  type: 'GET',
											  cache: false,
									success: function (logindata) {
										
										if(logindata!=null){
											var check=loginpass.localeCompare(logindata.Password);
											if(check==0){
											sessionStorage.setItem("user", loginname); 
											
												console.log("success");
											}else{
												console.log("fail");
											}
											
			
		}else{
			console.log("fail");
		}	
										
									}});
			
		}else{
			$.ajax({
						  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Email%22:%20%22'+loginname+'%22}&fo=true&apiKey='+secure+'',
						  dataType: "json",
						  type: 'GET',
						  cache: false,
		success: function (logindata) {
			
			if(logindata!=null){
				var check=loginpass.localeCompare(logindata.Password);
									if(check==0){
										sessionStorage.setItem("user", loginname); 
										
										console.log("success");
									            }else{
												console.log("fail");
											}
								}else{
										console.log("fail");
									}	
						}});
			
		}
			
		}else{
			
			console.log(s);
			console.log("you are already logged in....");
		}
													
		});		
	});