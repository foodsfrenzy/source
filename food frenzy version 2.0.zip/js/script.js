/* function is for registring a user */
$(document).ready(function(){
	$("#registeruser").on('submit',function(e){
		e.preventDefault();                // not refresh the page while clicked on submit button
		console.log('submitted');
		var name = $("#uname").val();
		var email = $("#uemail").val();
		var pass = $("#upass").val();
		var contact = $("#ucontact").val();
		var secure = "JgWnXBbal3mek-EMSQEzrdrUhFvsLLBi";
		$.ajax({
			  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Email%22:%20%22'+email+'%22}&fo=true&apiKey='+secure+'',
			  dataType: "json",     // api url hit db to check the user already exists
			  type: 'GET',
			  cache: false,
			  success: function (data) {
				//the variable 'data' will have the JSON object
				// In your example, the following will work:
				// data will not be null if the user with 
				
				if(data==null){
					
					console.log('Email Doesnot Exist');
					$.ajax({
						  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Contact%22:%22'+contact+'%22}&fo=true&apiKey='+secure+'',
						  dataType: "json",
						  type: 'GET',
						  cache: false,
							success: function (contactdata) {
						
						if(contactdata == null){
							console.log('Contact Doesnot Exist');
							
							$.toast({
																heading: 'Failed',
																text: 'Email Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'success',
																bgColor: '#5EEA50',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#9EC600',
																hideAfter: 6000,																
																stack: false,
																
												})
							$.ajax({ 
									url: "https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?apiKey="+ secure +"",
									data: JSON.stringify( { 
									"Name" : name,
									"Email" : email,
									"Password": pass,
									"Contact": contact
									
									} ),
									type: "POST",
									contentType: "application/json",
									success: function(data){
										
										$.toast({
																heading: 'success',
																text: 'Registered Successfully',
																position: 'top-center',
																allowToastClose: true,
																icon: 'success',
																bgColor: '#5EEA50',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#9EC600',
																hideAfter: 6000,																
																stack: false,
																afterShown: function () {
																	window.location.replace("index.html");
																}
												})
										
										
										
									},
									error: function(xhr, status, err){
										
										
									}
							});
						
							
							
						}
						else {
						console.log('Contact Exist');
						}
						
					}
					
					
					
					});
					
					
					
				}
				else {
					
					
						console.log('User Exists');
						
						
					
					
					
				}
			   
			  }
			});
		
		
		
	});
	
	
});
$(document).ready(function(){
	$("#loginuser").on('submit',function(e){
		e.preventDefault();
		console.log("clicked");
		var secure = "JgWnXBbal3mek-EMSQEzrdrUhFvsLLBi";
		var loginname = $("#loginname").val();
		var loginpass = $("#loginpass").val();
		var check=loginname.search("@");
		var s=sessionStorage.getItem("user");
		if(s==null){
					if(check==(-1)){
								$.ajax({
											  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Contact%22:%20%22'+loginname+'%22}&fo=true&apiKey='+secure+'',
											  dataType: "json",
											  type: 'GET',
											  cache: false,
									success: function (logindata) {
										
										if(logindata!=null){
											var check=loginpass.localeCompare(logindata.Password);
											if(check==0){
											sessionStorage.setItem("user", logindata.Name); 
											
												console.log("success");
												
										$.toast({
																heading: 'success',
																text: 'Registered Successfully',
																position: 'top-center',
																allowToastClose: true,
																icon: 'success',
																bgColor: '#5EEA50',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#9EC600',
																hideAfter: 6000,																
																stack: false,
																afterShown: function () {
																	window.location.href="home.html";
																}
												})
												
											}else{
												console.log("fail");
												$.toast({
																heading: 'Failed',
																text: 'User Does not Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'warning',
																bgColor: '#B60E0E',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#fff',
																hideAfter: 6000,																
																stack: false
																
												})
												
											}
											
			
		}else{
			console.log("fail");
											$.toast({
																heading: 'Failed',
																text: 'User Does not Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'warning',
																bgColor: '#B60E0E',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#fff',
																hideAfter: 6000,																
																stack: false
																
												})
		}	
										
									}});
			
		}else{
			$.ajax({
						  url: 'https://api.mlab.com/api/1/databases/system_food_frenzy/collections/loginuser?q={%22Email%22:%20%22'+loginname+'%22}&fo=true&apiKey='+secure+'',
						  dataType: "json",
						  type: 'GET',
						  cache: false,
		success: function (logindata) {
			
			if(logindata!=null){
				var check=loginpass.localeCompare(logindata.Password);
									if(check==0){
										sessionStorage.setItem("user", logindata.Name); 
										
										console.log("success");
										window.location.href="home.html";
										
									            }else{
												console.log("fail");
												$.toast({
																heading: 'Failed',
																text: 'User Does not Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'warning',
																bgColor: '#B60E0E',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#fff',
																hideAfter: 6000,																
																stack: false
																
												})
											}
								}else{$.toast({
																heading: 'Failed',
																text: 'User Does not Exist',
																position: 'top-center',
																allowToastClose: true,
																icon: 'warning',
																bgColor: '#B60E0E',
																textColor: 'white',
																textAlign: 'center',
																loaderBg: '#fff',
																hideAfter: 6000,																
																stack: false
																
												})
										console.log("fail");
										
									}	
						}});
			
		}
			
		}else{
			
			console.log(s);
			console.log("you are already logged in....");
			window.location.href="home.html";
		}
		return false;											
		});		
	});